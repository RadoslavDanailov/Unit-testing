package farmville;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class FarmvilleTests {
    private Farm farm;

    @Before
    public void setUp(){
        farm = new Farm("AnimalFarm", 2);
    }

    @Test
    public void testGetCont() {
        Animal animal1 = new Animal("Dory", 5);
        Animal animal2 = new Animal("Cora", 7);
        this.farm.add(animal1);
        this.farm.add(animal2);

        Assert.assertEquals(this.farm.getCount(), 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIfAnimalExist(){
        Animal animal1 = new Animal("Dory", 5);
        Animal animal2 = new Animal("Cora", 7);
        this.farm.add(animal1);
        this.farm.add(animal1);

    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddFullCapacity(){
        Animal animal1 = new Animal("Dory", 5);
        Animal animal2 = new Animal("Cora", 7);
        Animal animal3 = new Animal("Lola", 8);
        this.farm.add(animal1);
        this.farm.add(animal2);
        this.farm.add(animal3);
    }

    @Test
    public void testRemoveAnimal(){
        Animal animal1 = new Animal("Dory", 5);
        Animal animal2 = new Animal("Cora", 7);
        this.farm.add(animal1);
        this.farm.add(animal2);

        this.farm.remove("Cora");
        Assert.assertEquals(this.farm.getCount(), 1);
    }

    @Test
    public void testSetCapacity(){
        farm = new Farm("SeaFarm", 5);
        Assert.assertEquals(this.farm.getCapacity(), 5);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMinusCapacity(){
        farm = new Farm("Farm", -3);
    }

    @Test
    public void testSetName(){
        Assert.assertEquals(this.farm.getName(), "AnimalFarm");
    }

    @Test(expected = NullPointerException.class)
    public void testNullOrEmptyName(){
        farm = new Farm(null, 5);

    }

}
