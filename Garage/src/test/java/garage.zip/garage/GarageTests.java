package garage;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class GarageTests {
    private Garage garage;

    @Before
    public void setUp(){
        garage = new Garage();
    }

    @Test
    public void testAddCarToGarage(){

        Assert.assertEquals(0, this.garage.getCount());

        Car car = new Car("Skoda", 220, 35000);

        this.garage.addCar(car);
        List<Car>carsList = this.garage.getCars();
        Assert.assertEquals(car, carsList.get(0));
        Assert.assertEquals(1, this.garage.getCount());

    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddCarNull(){
        this.garage.addCar(null);
    }

    @Test
    public void testFindAllCarsByBrand(){

        Car SkodaKamik = new Car("Skoda", 220, 35000);
        Car Fiat = new Car("Fiat", 200, 25000);
        Car Seat = new Car("Seat", 260, 45000);
        Car SkodaKaroq = new Car("Skoda", 250, 65000);

        this.garage.addCar(SkodaKaroq);
        this.garage.addCar(Fiat);
        this.garage.addCar(Seat);
        this.garage.addCar(SkodaKamik);

        List<Car> carList = this.garage.findAllCarsByBrand("Skoda");

        Assert.assertEquals(2, carList.size());
        Assert.assertEquals(SkodaKaroq, carList.get(0));
        Assert.assertEquals(SkodaKamik, carList.get(1));
    }

    @Test
    public void testFindCarByMaxSpeed(){
        Car SkodaKamik = new Car("Skoda", 220, 35000);
        Car Fiat = new Car("Fiat", 200, 25000);
        Car Seat = new Car("Seat", 260, 45000);
        Car SkodaKaroq = new Car("Skoda", 250, 65000);
        this.garage.addCar(SkodaKamik);
        this.garage.addCar(Fiat);
        this.garage.addCar(Seat);
        this.garage.addCar(SkodaKaroq);

        List<Car> carList = this.garage.findAllCarsWithMaxSpeedAbove(200);

        Assert.assertEquals(3, carList.size());
        Assert.assertEquals(SkodaKamik, carList.get(0));
        Assert.assertEquals(Seat, carList.get(1));
        Assert.assertEquals(SkodaKaroq, carList.get(2));

    }

    @Test
    public void testFindMostExpensiveCar(){
        Car SkodaKamik = new Car("Skoda", 220, 35000);
        Car Fiat = new Car("Fiat", 200, 25000);
        Car Seat = new Car("Seat", 260, 45000);
        Car SkodaKaroq = new Car("Skoda", 250, 65000);
        this.garage.addCar(SkodaKamik);
        this.garage.addCar(Fiat);
        this.garage.addCar(Seat);
        this.garage.addCar(SkodaKaroq);

        Car mostExpensive = this.garage.getTheMostExpensiveCar();

        Assert.assertEquals(mostExpensive, SkodaKaroq);

    }
}